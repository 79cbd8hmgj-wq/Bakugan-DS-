Linux x86_64 DeSmuME build with ARM9 GDB stub enabled.

Example:
  ./run-desmume-debug.sh --arm9gdb=20000 /path/to/game.nds
